# JavaScript Events Homework

## Link to repo on GitHub
https://github.com/cgoconnor/hw_listeners_oconnor_caity

## Resources
* https://www.websitemagazine.com/blog/15-inspiring-design-quotes
    * Source of quotes
* https://thenextweb.com/dd/2012/04/23/searching-for-design-inspiration-heres-97-of-the-best-places-too-look/
    * Source of first two inspirational websites
* https://unsplash.com
    * Source of photos

## Deductions
I reviewed the list of deductions for this project and in the syllabus.

## Comments
I have no comments at this time
